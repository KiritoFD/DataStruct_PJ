import re
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from sklearn.metrics import r2_score, mean_squared_error

# 1. 读取并解析数据
with open("results/summary.txt", "r") as f:
    data_lines = f.readlines()

# 正则表达式匹配每行
pattern = re.compile(
    r"NUM_CENTROIDS=(\d+) KMEANS_ITER=(\d+) NPROBE=(\d+) .* RECALL=([\d.]+) AVG_QUERY_TIME_ms=([\d.]+)"
)

records = []
for line in data_lines:
    match = pattern.search(line)
    if match:
        C = int(match.group(1))
        I = int(match.group(2))
        P = int(match.group(3))
        recall = float(match.group(4))
        time_ms = float(match.group(5))
        records.append((C, I, P, recall, time_ms))

df = pd.DataFrame(records, columns=["C", "I", "P", "recall", "time_ms"])
print(f"Loaded {len(df)} valid records.")

# 2. 拟合平均查询时间模型（按 KMEANS_ITER 分组）
print("\n=== Time Model Fitting ===")
time_results = {}

for I in sorted(df["I"].unique()):
    df_i = df[df["I"] == I].copy()
    X = df_i[["C", "P"]].values
    y = df_i["time_ms"].values

    # 线性回归: T = a*C + b*P + d
    A = np.column_stack([X[:, 0], X[:, 1], np.ones(len(X))])
    coeffs, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
    a, b, d = coeffs

    y_pred = A @ coeffs
    rmse = np.sqrt(mean_squared_error(y, y_pred))
    r2 = r2_score(y, y_pred)

    time_results[I] = {
        "params": {"a": a, "b": b, "d": d},
        "rmse_ms": rmse,
        "r2": r2,
        "n": len(y)
    }
    print(f"I={I}: T = {a:.6f}*C + {b:.6f}*P + {d:.3f} | RMSE={rmse:.3f} ms, R²={r2:.3f}")

# 3. 拟合召回率模型（按 KMEANS_ITER 分组）
print("\n=== Recall Model Fitting ===")
def recall_model(x, A, B):
    # x = [P, C]
    P, C = x
    ratio = P / C
    return 1 - A * np.exp(-B * ratio)

recall_results = {}

for I in sorted(df["I"].unique()):
    df_i = df[df["I"] == I].copy()
    P_vals = df_i["P"].values
    C_vals = df_i["C"].values
    R_vals = df_i["recall"].values

    x_data = (P_vals, C_vals)

    try:
        popt, _ = curve_fit(recall_model, x_data, R_vals, p0=[0.1, 5.0], bounds=([0, 0], [2, 50]))
        A_fit, B_fit = popt
        R_pred = recall_model(x_data, A_fit, B_fit)
        rmse = np.sqrt(mean_squared_error(R_vals, R_pred))
        r2 = r2_score(R_vals, R_pred)

        recall_results[I] = {
            "params": {"A": A_fit, "B": B_fit},
            "rmse": rmse,
            "r2": r2,
            "n": len(R_vals)
        }
        print(f"I={I}: R = 1 - {A_fit:.3f} * exp(-{B_fit:.3f} * P/C) | RMSE={rmse:.4f}, R²={r2:.3f}")
    except Exception as e:
        print(f"I={I}: Fit failed - {e}")
        recall_results[I] = None

# 4. 找出 Recall >= 0.98 且 time_ms 最小的点
print("\n=== Optimal Configuration (Recall >= 98%) ===")
df_target = df[df["recall"] >= 0.98].copy()
if not df_target.empty:
    best_row = df_target.loc[df_target["time_ms"].idxmin()]
    print(f"Best config:")
    print(f"  NUM_CENTROIDS = {int(best_row['C'])}")
    print(f"  KMEANS_ITER    = {int(best_row['I'])}")
    print(f"  NPROBE         = {int(best_row['P'])}")
    print(f"  Recall         = {best_row['recall']:.4f} ({best_row['recall']*100:.2f}%)")
    print(f"  AVG_QUERY_TIME = {best_row['time_ms']:.2f} ms")
else:
    print("No configuration achieves Recall >= 98%")

# 5. （可选）保存拟合结果
import json

output = {
    "time_model": time_results,
    "recall_model": recall_results,
    "meta": {
        "summary_path": "results/summary.txt",
        "total_records": len(df),
        "I_values": sorted(df["I"].unique().tolist())
    }
}

with open("fitted_models.json", "w") as f:
    json.dump(output, f, indent=2, default=float)

print("\nFitted models saved to 'fitted_models.json'")